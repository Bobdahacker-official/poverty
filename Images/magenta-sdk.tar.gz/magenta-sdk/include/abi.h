#ifndef AVALANCHE_ABI_H
#define AVALANCHE_ABI_H
/* Native x86-64 int 0x80: RAX number/result; RBX, RCX, RDX, RSI arguments.
 * Service addresses are bounded below 4 GiB. Native programs are ELF64 ET_EXEC.
 * Linux ELF32 programs use a separate i386 compatibility dispatcher. */
enum {
  AV_EXIT,
  AV_WRITE,
  AV_READLINE,
  AV_TICKS,
  AV_FILE_READ,
  AV_FILE_WRITE,
  AV_FILE_REMOVE,
  AV_FILE_LIST,
  AV_SLEEP,
  AV_UDP_SEND,
  AV_UDP_RECV,
  AV_ARGS,
  AV_FILE_SIZE,
  AV_YIELD,
  AV_TCP_CONNECT,
  AV_TCP_SEND,
  AV_TCP_RECV,
  AV_TCP_CLOSE,
  AV_DNS,
  AV_SPAWN,
  AV_WAIT,
  AV_GETPID,
  AV_KILL,
  AV_STATUS,
  AV_REPORT,
  AV_CLEAR,
  AV_COLOR,
  AV_FILE_ENTRY,
  AV_DHCP,
  AV_NET_CONFIG,
  AV_PING,
  AV_POWER,
  AV_PACKAGE,
  AV_RANDOM,
  AV_AUDIO_PLAY,
  AV_AUDIO_STATUS,
  AV_AUDIO_STOP,
  AV_FILE_MKDIR,
  AV_FILE_RENAME,
  AV_FILE_COPY,
  AV_TASK_INFO
};
#define AV_USER_BASE 0x40000000u
#define AV_USER_END 0x44000000u
#endif
